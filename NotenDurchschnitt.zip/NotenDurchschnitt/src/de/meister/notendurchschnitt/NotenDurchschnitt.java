package de.meister.notendurchschnitt;



import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

@SuppressLint({ "ParserError", "ParserError" })
public class NotenDurchschnitt extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noten_durchschnitt);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_noten_durchschnitt, menu);
        return true;
    }

   
    
    
    
    
    public void Noten(View view){
    	setContentView(R.layout.noten);	
    }
    
    
    
	public void Speichern(View view){
    int i = 0 , k = 1;
    double s1 , s2;
    if(i<k){
    
    int note[] = new int[i];
    
   
    EditText Note = (EditText)findViewById(R.id.editText1);
    
    note[i] = Integer.parseInt(Note.getText().toString());
    
    
    
   
    	s1 = note[0] + note[1];
    	s2 = s1 / k;
    	
    	EditText Ergebnis = (EditText)findViewById(R.id.editText2);
        Ergebnis.setText(String.valueOf(s2));  
     i++; k++; 	
    	
    
    }
    
    
    
    
    	
    		
    	
    
    
    	
    
    }
    
}
