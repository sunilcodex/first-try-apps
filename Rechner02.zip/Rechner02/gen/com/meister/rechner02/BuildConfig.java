/** Automatically generated file. DO NOT MODIFY */
package com.meister.rechner02;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}